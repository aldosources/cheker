package org.apache.http.auth.params;

@Deprecated
public interface AuthPNames {
    public static final String CREDENTIAL_CHARSET = "http.auth.credential-charset";
}
