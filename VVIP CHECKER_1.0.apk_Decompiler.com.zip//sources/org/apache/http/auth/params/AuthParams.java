package org.apache.http.auth.params;

import org.apache.http.params.HttpParams;

@Deprecated
public final class AuthParams {
    AuthParams() {
        throw new RuntimeException("Stub!");
    }

    public static String getCredentialCharset(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    public static void setCredentialCharset(HttpParams params, String charset) {
        throw new RuntimeException("Stub!");
    }
}
