package org.apache.http.auth;

import java.security.Principal;

@Deprecated
public final class BasicUserPrincipal implements Principal {
    public BasicUserPrincipal(String username) {
        throw new RuntimeException("Stub!");
    }

    public String getName() {
        throw new RuntimeException("Stub!");
    }

    public int hashCode() {
        throw new RuntimeException("Stub!");
    }

    public boolean equals(Object o) {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }
}
