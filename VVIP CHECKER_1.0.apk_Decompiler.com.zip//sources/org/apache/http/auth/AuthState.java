package org.apache.http.auth;

@Deprecated
public class AuthState {
    public AuthState() {
        throw new RuntimeException("Stub!");
    }

    public void invalidate() {
        throw new RuntimeException("Stub!");
    }

    public boolean isValid() {
        throw new RuntimeException("Stub!");
    }

    public void setAuthScheme(AuthScheme authScheme) {
        throw new RuntimeException("Stub!");
    }

    public AuthScheme getAuthScheme() {
        throw new RuntimeException("Stub!");
    }

    public Credentials getCredentials() {
        throw new RuntimeException("Stub!");
    }

    public void setCredentials(Credentials credentials) {
        throw new RuntimeException("Stub!");
    }

    public AuthScope getAuthScope() {
        throw new RuntimeException("Stub!");
    }

    public void setAuthScope(AuthScope authScope) {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }
}
