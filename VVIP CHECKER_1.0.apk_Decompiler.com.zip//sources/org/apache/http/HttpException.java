package org.apache.http;

@Deprecated
public class HttpException extends Exception {
    public HttpException() {
        throw new RuntimeException("Stub!");
    }

    public HttpException(String message) {
        throw new RuntimeException("Stub!");
    }

    public HttpException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
