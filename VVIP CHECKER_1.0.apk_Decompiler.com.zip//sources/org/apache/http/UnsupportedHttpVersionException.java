package org.apache.http;

@Deprecated
public class UnsupportedHttpVersionException extends ProtocolException {
    public UnsupportedHttpVersionException() {
        throw new RuntimeException("Stub!");
    }

    public UnsupportedHttpVersionException(String message) {
        throw new RuntimeException("Stub!");
    }
}
