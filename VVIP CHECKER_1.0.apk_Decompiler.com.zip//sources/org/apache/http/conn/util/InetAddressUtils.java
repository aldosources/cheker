package org.apache.http.conn.util;

@Deprecated
public class InetAddressUtils {
    InetAddressUtils() {
        throw new RuntimeException("Stub!");
    }

    public static boolean isIPv4Address(String input) {
        throw new RuntimeException("Stub!");
    }

    public static boolean isIPv6StdAddress(String input) {
        throw new RuntimeException("Stub!");
    }

    public static boolean isIPv6HexCompressedAddress(String input) {
        throw new RuntimeException("Stub!");
    }

    public static boolean isIPv6Address(String input) {
        throw new RuntimeException("Stub!");
    }
}
