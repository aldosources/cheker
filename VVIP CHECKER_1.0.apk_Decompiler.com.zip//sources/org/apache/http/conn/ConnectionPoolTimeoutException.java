package org.apache.http.conn;

@Deprecated
public class ConnectionPoolTimeoutException extends ConnectTimeoutException {
    public ConnectionPoolTimeoutException() {
        throw new RuntimeException("Stub!");
    }

    public ConnectionPoolTimeoutException(String message) {
        throw new RuntimeException("Stub!");
    }
}
