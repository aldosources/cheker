package org.apache.http;

@Deprecated
public class MethodNotSupportedException extends HttpException {
    public MethodNotSupportedException(String message) {
        throw new RuntimeException("Stub!");
    }

    public MethodNotSupportedException(String message, Throwable cause) {
        throw new RuntimeException("Stub!");
    }
}
