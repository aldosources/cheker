package org.apache.http.util;

@Deprecated
public final class CharArrayBuffer {
    public CharArrayBuffer(int capacity) {
        throw new RuntimeException("Stub!");
    }

    public void append(char[] b, int off, int len) {
        throw new RuntimeException("Stub!");
    }

    public void append(String str) {
        throw new RuntimeException("Stub!");
    }

    public void append(CharArrayBuffer b, int off, int len) {
        throw new RuntimeException("Stub!");
    }

    public void append(CharArrayBuffer b) {
        throw new RuntimeException("Stub!");
    }

    public void append(char ch) {
        throw new RuntimeException("Stub!");
    }

    public void append(byte[] b, int off, int len) {
        throw new RuntimeException("Stub!");
    }

    public void append(ByteArrayBuffer b, int off, int len) {
        throw new RuntimeException("Stub!");
    }

    public void append(Object obj) {
        throw new RuntimeException("Stub!");
    }

    public void clear() {
        throw new RuntimeException("Stub!");
    }

    public char[] toCharArray() {
        throw new RuntimeException("Stub!");
    }

    public char charAt(int i) {
        throw new RuntimeException("Stub!");
    }

    public char[] buffer() {
        throw new RuntimeException("Stub!");
    }

    public int capacity() {
        throw new RuntimeException("Stub!");
    }

    public int length() {
        throw new RuntimeException("Stub!");
    }

    public void ensureCapacity(int required) {
        throw new RuntimeException("Stub!");
    }

    public void setLength(int len) {
        throw new RuntimeException("Stub!");
    }

    public boolean isEmpty() {
        throw new RuntimeException("Stub!");
    }

    public boolean isFull() {
        throw new RuntimeException("Stub!");
    }

    public int indexOf(int ch, int beginIndex, int endIndex) {
        throw new RuntimeException("Stub!");
    }

    public int indexOf(int ch) {
        throw new RuntimeException("Stub!");
    }

    public String substring(int beginIndex, int endIndex) {
        throw new RuntimeException("Stub!");
    }

    public String substringTrimmed(int beginIndex, int endIndex) {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }
}
