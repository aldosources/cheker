package org.apache.http.util;

@Deprecated
public final class ByteArrayBuffer {
    public ByteArrayBuffer(int capacity) {
        throw new RuntimeException("Stub!");
    }

    public void append(byte[] b, int off, int len) {
        throw new RuntimeException("Stub!");
    }

    public void append(int b) {
        throw new RuntimeException("Stub!");
    }

    public void append(char[] b, int off, int len) {
        throw new RuntimeException("Stub!");
    }

    public void append(CharArrayBuffer b, int off, int len) {
        throw new RuntimeException("Stub!");
    }

    public void clear() {
        throw new RuntimeException("Stub!");
    }

    public byte[] toByteArray() {
        throw new RuntimeException("Stub!");
    }

    public int byteAt(int i) {
        throw new RuntimeException("Stub!");
    }

    public int capacity() {
        throw new RuntimeException("Stub!");
    }

    public int length() {
        throw new RuntimeException("Stub!");
    }

    public byte[] buffer() {
        throw new RuntimeException("Stub!");
    }

    public void setLength(int len) {
        throw new RuntimeException("Stub!");
    }

    public boolean isEmpty() {
        throw new RuntimeException("Stub!");
    }

    public boolean isFull() {
        throw new RuntimeException("Stub!");
    }
}
