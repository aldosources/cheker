package org.apache.http.util;

import java.io.IOException;
import org.apache.http.HttpEntity;
import org.apache.http.ParseException;

@Deprecated
public final class EntityUtils {
    EntityUtils() {
        throw new RuntimeException("Stub!");
    }

    public static byte[] toByteArray(HttpEntity entity) throws IOException {
        throw new RuntimeException("Stub!");
    }

    public static String getContentCharSet(HttpEntity entity) throws ParseException {
        throw new RuntimeException("Stub!");
    }

    public static String toString(HttpEntity entity, String defaultCharset) throws IOException, ParseException {
        throw new RuntimeException("Stub!");
    }

    public static String toString(HttpEntity entity) throws IOException, ParseException {
        throw new RuntimeException("Stub!");
    }
}
