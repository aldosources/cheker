package org.apache.http.util;

@Deprecated
public final class EncodingUtils {
    EncodingUtils() {
        throw new RuntimeException("Stub!");
    }

    public static String getString(byte[] data, int offset, int length, String charset) {
        throw new RuntimeException("Stub!");
    }

    public static String getString(byte[] data, String charset) {
        throw new RuntimeException("Stub!");
    }

    public static byte[] getBytes(String data, String charset) {
        throw new RuntimeException("Stub!");
    }

    public static byte[] getAsciiBytes(String data) {
        throw new RuntimeException("Stub!");
    }

    public static String getAsciiString(byte[] data, int offset, int length) {
        throw new RuntimeException("Stub!");
    }

    public static String getAsciiString(byte[] data) {
        throw new RuntimeException("Stub!");
    }
}
