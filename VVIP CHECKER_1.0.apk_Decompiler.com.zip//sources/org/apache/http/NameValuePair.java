package org.apache.http;

@Deprecated
public interface NameValuePair {
    String getName();

    String getValue();
}
